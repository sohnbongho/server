#pragma once

extern class ThreadManager*		GThreadManager;
extern class Memory*			GMemory;

extern class DeadLockProfiler*	GDeadLockProfiler;

