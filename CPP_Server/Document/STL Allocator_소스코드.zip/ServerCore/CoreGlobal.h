#pragma once

extern class ThreadManager* GThreadManager;

extern class DeadLockProfiler* GDeadLockProfiler;

