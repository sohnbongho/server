#pragma once

extern class ThreadManager* GThreadManager;

class CoreGlobal
{
public:
	CoreGlobal();
	~CoreGlobal();
};

